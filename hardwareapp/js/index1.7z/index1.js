	"use strict";
	class Index1{
	constructor(){
	this.media=[{
	"img":"http://acemcquades.com/files/9514/5496/0717/tools_cropped.jpg",
	"slogan":"Visit our hardware tools",
	"caption":"Explore",
	"alignment":"center-align",
	"button":"btn-large waves-effect waves-light orange green-text text-darken-3",
	"button_caption":"Soon to open"

},
{
	"img":"http://www.palmtraders.in/img/slider/2nd.jpg",
	"caption":"Our Electrical Products",
	"slogan":"are one of the finest",
	"alignment":"left-align",
	"button":"btn-large waves-effect waves-light lime lighten-1 green-text text-darken-4",
	"button_caption":"Soon to open"
},
{
	"img":"http://www.innovus.org/wp-content/uploads/2016/08/Computer-Hardware.jpg",
	"slogan":"are also accepted here",
	"caption":"COMPUTER HARDWARES",
	"alignment":"right-align",
	"button":"btn-large waves-effect waves-light cyan lighten-3 green-text text-darken-3",
	"button_caption":"Soon to open"
}		
];
this.featured=[{
"img":"http://my-live-01.slatic.net/p/powerful-cordless-set-of-45-screw-driver-andamp-drill-head-sets-5629-0450293-1-product.jpg",
"name":"Powerful Cordless: Set of 45 Screw Driver & Drill Head Sets",
"description":"Cordless Screwdriver4x 50mm Screw Head Attachments 2x Drill Attachments 28x Screw Head Attachments 8x Socket Attachments Magnectic Screw Attachment Fixture User Manual Tool Box"
,"id":1,
"cost":"Php 1.00",
"warranty":"No warranty",
"details":["Cable type: UTP",
"Plug: 8P8C RJ45 gold connector",
"Transmission rate: 500MHZ in 10GBase-T ethernet",
"Length: 10m"
]
},
{
	"img":"https://ae01.alicdn.com/kf/HTB1W8XQMFXXXXabXXXXq6xXFXXXo/Novelty-3D-Decor-Bulbing-Light-LED-Star-Wars-Millennium-Falcon-LED-Lighting-font-b-Gadget-b.jpg",
	"name":"StarWAR illusion 3D Led night light Visual Home kitchen table Lamp Station - B",
	"description":"	1 x StarWAR illusion 3D Led night light Visual Home kitchen table Lamp Station"
	,"id":2,
	"cost":"Php 1.00",
	"warranty":"No warranty",
	"details":["Cable type: UTP",
	"Plug: 8P8C RJ45 gold connector",
	"Transmission rate: 500MHZ in 10GBase-T ethernet",
	"Length: 10m"
	]
},
{
	"img":"https://images-na.ssl-images-amazon.com/images/I/81WOZeCgWhL._SL1500_.jpg",
	"name":"Intel Boxed Core I5-6600K 3.50 GHz, 6 M Processor Cache 6 for LGA 1151 (BX80662I56600K)",
	"description":"1x Intel Boxed Core I5-6600K 3.50 GHz, 6 M Processor Cache 6 for LGA 1151 (BX80662I56600K) with Corsair Hydro Series H100i v2 Extreme Performance Liquid CPU Cooler"
	,"id":3,
	"cost":"Php 1.00",
	"warranty":"No warranty",
	"details":["Cable type: UTP",
	"Plug: 8P8C RJ45 gold connector",
	"Transmission rate: 500MHZ in 10GBase-T ethernet",
	"Length: 10m"
	]
},
{
	"img":"https://www.pugetsystems.com/pic_disp.php?id=14454",
	"name":"Intel Original CPU Fan & Heatsink for Socket 775 Processor",
	"description":"1 x Intel Original CPU Fan & Heatsink for Socket 775 Processor"
	,"id":4,
	"cost":"Php 1.00",
	"warranty":"No warranty",
	"details":["Cable type: UTP",
	"Plug: 8P8C RJ45 gold connector",
	"Transmission rate: 500MHZ in 10GBase-T ethernet",
	"Length: 10m"
	]
},		
{
	"img":"http://my-live-01.slatic.net/p/bosch-2608643045-tct-saw-blade-356mm-6-1-4-x-20t-bore-size-20mm-wood-for-gks66x-use-4431-62278741-c16d1003818368c9d20de5bffa35bb75-catalog_233.jpg",
	"name":"Bosch 2608643045 TCT Saw Blade 356mm 6 1/4' x 20T Bore Size 20mm Wood (For GKS66X Use)",
	"description":"	1x Bosch 2608643045 TCT Saw Blade 356mm 6 1/4' x 20T Bore Size 20mm Wood (For GKS66X Use)",
	"id":5,
	"cost":"Php 1.00",
	"warranty":"No warranty",
	"details":["Cable type: UTP",
	"Plug: 8P8C RJ45 gold connector",
	"Transmission rate: 500MHZ in 10GBase-T ethernet",
	"Length: 10m"
	]
},
{
	"img":"http://my-live-01.slatic.net/p/2/buyincoins-30ft-10m-cat6-cat-6-flat-utp-ethernet-network-cable-rj45-patch-lan-cord-6532-7028005-390a9b8bee3c4c3d4baac2a12c05b4c5-catalog_233.jpg",
	"name":"BUYINCOINS CAT6 CAT 6 Flat UTP Ethernet Network Cable RJ45 Patch LAN Cord",
	"description":"1 x BUYINCOINS 30ft 10M CAT6 CAT 6 Flat UTP Ethernet Network Cable RJ45 Patch LAN Cord",
	"warranty":"No warranty",
	"size":"21 X 21 X 21",
	"id":6,
	"cost":"Php 1.00",

	"details":["Cable type: UTP",
	"Plug: 8P8C RJ45 gold connector",
	"Transmission rate: 500MHZ in 10GBase-T ethernet",
	"Length: 10m"
	]
}
];
}
render(html,component){
component.innerHTML += html;
}

reRender(html,component){
component.innerHTML = html;

}
readHardware(){
let list=document.getElementById("hardwinfo");
let html = ``;
let r = this.featured;
for(let i=0;i<this.featured.length;i++){
html +=`
<tr>
	<td>${this.featured[i].name}</td>
	<td>${this.featured[i].description}</td>
	<td><a href="#" class="waves-effect waves-light btn" onclick="component.moreDetails(${[i]})">More</a></td>
	`;
}
list.innerHTML = html;
}

moreDetailsInfo(key){
let hardwareInfo = document.getElementById("seeinfo");
let html=`
<div class="section no-pad-bot">
	<div id="view" class="container">
		<div class="row">
			<div class="col s12 m12">
				<center><h1>${this.featured[key].name}</h1></center><br>
			</div>
			<div class="col s12 m12">
				<center><img src="${this.featured[key].img}"></center>
			</div>
		</div>
	</div><hr>
	<div class="row">						
		<div class="col s12 m12">			
			<div class="card horizontal small">
				<div class="card-stacked">
					<center>
						<a class="waves-effect waves-light btn green">Add to Cart</a>
						<a class="waves-effect waves-light btn red">Delete</a>
						<a class="waves-effect waves-light btn blue">Update</a>
					</center>
					<div class="card-content">
						Description:<br>${this.featured[key].description}<br>
						Size:<br>${this.featured[key].size}<br>
						Warranty:<br>${this.featured[key].warranty}<br>
						Details:<br>`;
						let r=this.featured;
						for(let i=0;i<r.length;i++){
						let rp = r[i].details;
						html += `
						<li class="collection-item avatar">
							<i class="material-icons circle green">done</i>
							
							<p>${rp}<br>
								
							</p>
							
						</li>
						`;
						html +=`<br>
						Price:
					</p>
					<p id="price">${this.featured[key].cost}</p>

				</div>
			</div>
		</div>
	</div>
</div>
`;
this.reRender(`${html}`,document.getElementById("seeinfo"));
}
}

searchHardware(){
let searchfirst = document.getElementById("searchfirst");
let hardwinfo = document.getElementById("hardwinfo");
let html=``;

for(let i=0;this.featured.length;i++){
if(this.featured[i].name.toLowerCase().includes(searchfirst.value)||this.featured[i].name.toLowerCase().includes(searchfirst.value)||this.featured[i].name.toUpperCase().includes(searchfirst.value)||this.featured[i].description.toLowerCase().includes(searchfirst.value)){
html+=`<tr>
<td>${this.featured[i].name}</td>
<td>${this.featured[i].description}</td>
<td><a href="#" class="waves-effect waves-light btn" onclick="component.moreDetails(${[i]})">More</td>
</tr>`;
}
}
hardwinfo.innerHTML =html;
}
}
class Component extends Index1{
constructor(){
super();
}
landingLayout(){
let html = `
<div class="navbar">
	<nav>

		<div class="nav-wrapper">
			<a href="#" class="brand-logo green-text"onclick="component.homepage()">HARDWARE Store</a>
			<ul id="nav-mobile" class="right hide-on-med-and-down">		
				<li><a href="#landinghead" onclick="component.homepage()">Home</a></li>
				<li><a href="#producto" onclick="component.productPage()">Products</a></li>
				<li><a href="#">Cart</a></li>
				<li><a href="#">Contribute</a></li>    		
			</ul>
		</div>
	</nav>
</div>
<div id="landinghead">
	<div id="index-banner" class="parallax-container">
		<div class="section no-pad-bot">
			<div class="container">
				<br><br>
				<h1 class="header center green-text text-darken-3">WELCOME SHOPPERS</h1>
				<div class="row center">

					<h5 class="header col s12 orange-text text-darken-3">Click Sign In if you already an account or Sign Up if you have no existing account</h5>

				</div>
				<div class="row center">
					<a href="#" id="submit" class="btn-large waves-effect waves-light transparent green-text">SIGN IN</a>
					<p class="blue-text text-darken-3">-OR-</p>
					<a href="#" id="submit" class="btn-large waves-effect waves-light teal lighten-1">SIGN UP</a>
				</div>
				<br><br>

			</div>
		</div>
		<div class="parallax"><img src=http://static.wixstatic.com/media/6423adc6fac9431890272f59c0b7ef88.jpg_srz_4000_2670_85_22_0.50_1.20_0.00_jpg_srz alt="Unsplashed background img 1"></div>
	</div>


	<div class="slider">/*slider*/
		<ul class="slides">

			`;

			for(let i=0;i<this.media.length;i++){
			html += `
			<li>
				<img src="${this.media[i].img}"> <!-- random image -->
				<div class="caption ${this.media[i].alignment}">
					<h3 class="light orange-text text-lighten-3">${this.media[i].caption}</h3>
					<h5 class="light green-text text-lighten-1">${this.media[i].slogan}</h5>
					<div class="row center">
						<a href="#" id="submit" class="${this.media[i].button}">${this.media[i].button_caption}</a>

					</div>
				</div>
			</li>

			`;
		}
		html += `
	</ul>
</div>

<div id="producto">
	<div class="container">
		<div class="row">
			<h5 class="center-align orange-text">Featured Products</h5>

			`;
			let r = this.featured;
			let count = 0;
			for(let i=(r.length-1);i>=0;i--){
			if(count++ === r.length)break;
			html+= `
			<div class="col s12 m4">
				<div class="card sticky-action large hoverable">
					<div class="card-image">
						<img class="activator"src="${r[i].img}">

					</div>
					<div class="card-content ">
						<span class="card activator blue-text">${r[i].name}</span>
					</div>
					<div class="card-reveal">
						<span class="card-title grey-text text-darken-4">${r[i].name
						}<i class="material-icons right">close</i></span>

						<p>Whats in the box:
							<br>${r[i].description}</p>
						</div>
						<div class="card-action">
							<a href="#" onclick="component.viewMore()">More</a>
							<a href="#" class="btn btn-info green waves-effect waves-light">Add to cart</a>
						</div>
					</div>
				</div>
				`;
			}

			html += `</div>
		</div><div class="container">
<div id="hardwinfo">

		<div id="seeinfo" class="scrollspy"></div>
	</div>	
</div>
</div>	
	
	<div class="form-group" id="mesearch">
		<input type="text" class="form-control" placeholder="Search" id="searchfirst" oninput="component.searchHardware()">
	</div>
		
	
`;

this.reRender(`
${html}
`,document.getElementById("index1"));
$('#mesearch').hide();
$('#seeinfo').hide();
}
homepage(){
$('#landinghead').show();
$('#producto').show();
$("#seeinfo").hide();
$("#mesearch").hide();
}
viewMore(){
$('#landinghead').hide();
$('#producto').show();
$("#seeinfo").show();
$("#mesearch").show();
$("hardwinfo").show();
}
moreDetails(key){
$('#landinghead').hide();
$('#producto').hide();
$("#seeinfo").show();
$("#mesearch").show();
component.moreDetailsInfo(key);
}
productPage(){
$('#landinghead').hide();
$('#producto').show();
$("#seeinfo").show();
$("#mesearch").show();
}

}

let component = new Component();
component.landingLayout();
component.readHardware();

